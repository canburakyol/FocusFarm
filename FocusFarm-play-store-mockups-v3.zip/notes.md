# FocusFarm Mockup V3

Karar: V2 zayifti; bu set daha cesur Play Store kreatifi olarak yeniden tasarlandi.

Rakiplerden alinan ders:
- Ilk bakista tek vaat okunmali.
- Telefon mockup urunu gostermeli ama tum tasarimi bogmamali.
- Bitki/gamification gorseli indirme motivasyonunu tasimali.
- Metin Turkce ve fayda odakli olmali.

Cikti:
- 6 adet 1080x1920 telefon screenshot
- 1 adet 1024x500 feature graphic
