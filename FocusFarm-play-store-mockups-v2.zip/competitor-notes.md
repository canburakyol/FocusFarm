# FocusFarm Play Store Mockup V2

Rakip taramasi ozeti:
- Forest: tek buyuk vaat, guclu maskot/bitki, odul rozetleri.
- Focus Plant: buyuk baslik + telefon mockup + net timer/grow plant mesajlari.
- Flora: gorevleri macera hissine baglayan daha parlak, sade sahneler.
- Focus Friend ve Study Bunny: sevimli karakteri ilk bakista gosteriyor.

Tasarim karari:
- Eski set uygulama ici ekran gibi duruyordu. V2 Play Store kreatifi gibi davranir: buyuk headline, telefon mockup, bitki/odul gorseli ve tek fayda.
- Palet mevcut Cozy Cream / Terracotta tema dosyasina yakindir.
- Cikti dosyalari mevcut assetleri ezmez; `mockup-v2` altindadir.
